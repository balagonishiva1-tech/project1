#!/bin/bash

python solution/fix_script.py